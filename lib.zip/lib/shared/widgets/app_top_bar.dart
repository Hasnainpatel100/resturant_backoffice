import '../../imports/core_imports.dart';
import '../../imports/packages_imports.dart';

class AppTopBar extends StatelessWidget implements PreferredSizeWidget {
  const AppTopBar({
    super.key,
    required this.title,
    this.titleWidget,
    this.actions,
    this.centerTitle = true,
    this.onPressed,
    this.isTransparent = false,
  });

  final String title;
  final Widget? titleWidget;
  final List<Widget>? actions;
  final VoidCallback? onPressed;
  final bool? centerTitle;
  final bool isTransparent;

  @override
  Widget build(BuildContext context) {
    final theme = context.theme;
    
    void handleBack() {
      if (onPressed != null) {
        onPressed!();
      } else {
        try {
          context.pop();
        } catch (_) {
          context.go(AppRoutes.home);
        }
      }
    }

    return AppBar(
      centerTitle: centerTitle,
      elevation: 0,
      backgroundColor: isTransparent ? Colors.transparent : null,
      shadowColor: Colors.transparent,
      title: titleWidget ??
          Text(
            title,
            style: theme.appBarTheme.titleTextStyle?.copyWith(
              fontWeight: FontWeight.w600,
            ) ?? theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
      leadingWidth: 40,
      leading: GestureDetector(
        onTap: handleBack,
        child: ColoredBox(
          color: Colors.transparent,
          child:               Icon(
                Icons.arrow_back,
                color: theme.appBarTheme.iconTheme?.color ?? theme.colorScheme.onSurface,
              )
            ,
        ),
      ),
      iconTheme: theme.appBarTheme.iconTheme,
      actions: actions ?? [],
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
