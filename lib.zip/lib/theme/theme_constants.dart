/// Barrel export for all theme constants.
///
/// Import this single file to access all design foundation values:
/// ```dart
/// import 'package:/theme/theme_constants.dart';
///
/// SizedBox(height: AppSpacing.md)
/// Container(decoration: BoxDecoration(borderRadius: AppBorders.card))
/// AnimatedContainer(duration: AppDurations.normal, curve: AppCurves.standard)
/// ```
library;

export 'app_borders.dart';
export 'app_curves.dart';
export 'app_durations.dart';
export 'app_shadows.dart';
export 'app_spacing.dart';
export 'color_schemes.dart';
export 'text_theme.dart';
export 'theme.dart';
